import { _decorator, Component, Node } from "cc";
import { DT_commandID_OP, DT_GAME_STATUS_EVENT } from "../../network/DT_networkDefine";
import { I_popup1_svice } from "../../common/dt_interfaceDefine";
import { DT_listRandomLocationTreasure_dataModel } from "../../model/DT_outputDataModel";
import { VDEventListener } from "../../../../../vd-framework/common/VDEventListener";
const { ccclass, property } = _decorator;

@ccclass("popup1_sevice")
export class popup1_sevice extends Component implements I_popup1_svice {
  getDataFromGamePlayScreen(data) {
    let dataID = data.id;
    switch (dataID) {
      case DT_commandID_OP.DT_LIST_RANDOM_LOCATION_TREASURE:
        console.log("data in popup 1 sevice", data);
    }
  }
  getDataFromGamePlayScreen_initLocationTreasure(data: DT_listRandomLocationTreasure_dataModel, listNode: Node[]) {
    console.log(data);
    VDEventListener.dispatchEvent(DT_GAME_STATUS_EVENT.SEND_TO_POPUP1_CTR_LIST_RANDOM_LOCATION_TREASURE, data, listNode);
  }
}
